from keras.preprocessing.image import ImageDataGenerator
from keras.optimizers.legacy import SGD
from task1_1 import load_images,load_labels,build_cnn,plot_graphs

#main parameters
input_shape = (32, 32, 1)  #based on my dataset shape
num_classes = 29  #num of labels in the arabic character
learning_rate = 0.00125892541179416752 #result from tuner
batch_size = 32
epochs = 10
dropout_rate=0.2 #result from tuner
momentum=0.9 #common choice

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)
train_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainImages 13440x1024.csv"
train_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainLabel 13440x1.csv"
test_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestImages 3360x1024.csv"
test_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestLabel 3360x1.csv"
train_images=load_images(train_images_path)
train_labels=load_labels(train_labels_path)
test_images=load_images(test_images_path)
test_labels=load_labels(test_labels_path)

datagen = ImageDataGenerator(
    width_shift_range=0.1,
    height_shift_range=0,
    shear_range=0.05,
    fill_mode='reflect' 
)

train_generator = datagen.flow(train_images, train_labels, batch_size=batch_size)
model = build_cnn()
# Train the model
history=model.fit(train_generator, epochs=epochs, validation_data=(test_images, test_labels))
plot_graphs(history)