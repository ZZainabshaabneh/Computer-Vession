import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, Lambda
from keras.optimizers.legacy import SGD
from keras.preprocessing.image import ImageDataGenerator
from task1_1 import load_images,load_labels,plot_graphs
from keras.applications import MobileNetV2
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras.preprocessing.image import ImageDataGenerator
from keras.layers.experimental import preprocessing


#main parameters
input_shape = (32, 32, 1)  #based on my dataset shape
num_classes = 29  #num of labels in the arabic character
learning_rate = 0.00125892541179416752 #result from tuner
batch_size = 32
epochs = 10
#dropout_rate=0.2 #result from tuner
momentum=0.9 #common choice

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)
train_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainImages 13440x1024.csv"
train_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainLabel 13440x1.csv"
test_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestImages 3360x1024.csv"
test_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestLabel 3360x1.csv"
train_images=load_images(train_images_path)
train_labels=load_labels(train_labels_path)
test_images=load_images(test_images_path)
test_labels=load_labels(test_labels_path)

datagen = ImageDataGenerator(
    width_shift_range=0.1,
    height_shift_range=0,
    shear_range=0.05,
    fill_mode='reflect' 
)

def pretrained_model():
    # Load pre-trained MobileNetV2 model without top layers
    base_model = MobileNetV2(include_top=False, input_shape=(32, 32, 3))

    # Unfreeze some top layers for fine-tuning
    for layer in base_model.layers[:-4]:
        layer.trainable = True  # unfreezes the last convolutional block of MobileNetV2 for fine-tuning.

    # Create a new model and add MobileNetV2 as a base
    model = Sequential()
    model.add(preprocessing.Rescaling(1./255, input_shape=(32, 32, 1)))  # Normalize pixel values
    model.add(tf.keras.layers.Lambda(lambda x: tf.image.grayscale_to_rgb(x)))  # Convert to RGB
    model.add(base_model)
    model.add(GlobalAveragePooling2D())
    model.add(Dense(256, activation='relu'))
    model.add(Dense(num_classes, activation='softmax'))

    # Compile the model
    model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

    return model
base_model=pretrained_model()

evaluation=base_model.fit(train_images, train_labels, epochs=epochs,validation_data=(test_images, test_labels))
plot_graphs(evaluation)
