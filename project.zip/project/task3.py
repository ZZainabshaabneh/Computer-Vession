import tensorflow as tf
from keras.models import Sequential
from keras.layers import Conv2D, AveragePooling2D, Flatten, Dense, BatchNormalization, Dropout
from keras.optimizers.legacy import SGD
from keras.preprocessing.image import ImageDataGenerator
from task1_1 import load_images,load_labels,plot_graphs

#main parameters
input_shape = (32, 32, 1)  #based on my dataset shape
num_classes = 29  #num of labels in the arabic character
learning_rate = 0.00125892541179416752 #result from tuner
batch_size = 32
epochs = 10
dropout_rate=0.2 #result from tuner
momentum=0.9 #common choice

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)
train_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainImages 13440x1024.csv"
train_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainLabel 13440x1.csv"
test_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestImages 3360x1024.csv"
test_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestLabel 3360x1.csv"
train_images=load_images(train_images_path)
train_labels=load_labels(train_labels_path)
test_images=load_images(test_images_path)
test_labels=load_labels(test_labels_path)

datagen = ImageDataGenerator(
    width_shift_range=0.1,
    height_shift_range=0,
    shear_range=0.05,
    fill_mode='reflect' 
)

def build_lenet():
    model = Sequential()
    #Conv 1
    model.add(Conv2D(24, kernel_size=(5, 5), strides=(1, 1), activation='tanh', input_shape=input_shape))
    #avg pooling 1
    model.add(AveragePooling2D(pool_size=(2, 2), strides=(2, 2)))
    #conv 2
    model.add(Conv2D(16, kernel_size=(5, 5), strides=(1, 1), activation='tanh'))
    #avg pooling 2
    model.add(AveragePooling2D(pool_size=(2, 2), strides=(2, 2)))
    #conv 3
    model.add(Conv2D(128, kernel_size=(5, 5), strides=(1, 1), activation='tanh'))
    #always flatten layer before fully connected layers
    model.add(Flatten())
    #fully connected layer 1
    model.add(Dense(128, activation='tanh'))
    model.add(Dropout(dropout_rate))  # Dropout layer to prevent overfitting
    #fully connected layer 2
    model.add(Dense(num_classes, activation='softmax'))
    #compiling the model with the same optimizer defined for all models
    model.compile(optimizer=optimizer,
                loss='categorical_crossentropy',
                metrics=['accuracy'])
    return model


train_generator = datagen.flow(train_images, train_labels, batch_size=batch_size)
lenet_model=build_lenet()
res=lenet_model.fit(train_generator, epochs=epochs, validation_data=(test_images, test_labels)) #combined with data augmentation made before
plot_graphs(res)