from keras.models import Sequential
from keras.layers import Conv2D, AveragePooling2D, Flatten, Dense, Dropout
from keras.optimizers.legacy import SGD
import keras_tuner as kt
from task1_1 import load_images,load_labels

#main parameters
input_shape = (32, 32, 1)  #based on my dataset shape
num_classes = 29  #num of labels in the arabic character
learning_rate = 0.00125892541179416752 #result from tuner
batch_size = 32
epochs = 10
dropout_rate=0.2 #result from tuner
momentum=0.9 #common choice

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)
#tuning LeNet-5 model's parameters to trade-off between complexity of layers and the accuracy obtained

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)
train_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainImages 13440x1024.csv"
train_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainLabel 13440x1.csv"
test_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestImages 3360x1024.csv"
test_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestLabel 3360x1.csv"
train_images=load_images(train_images_path)
train_labels=load_labels(train_labels_path)
test_images=load_images(test_images_path)
test_labels=load_labels(test_labels_path)
# Function to build the LeNet-5 model
def build_lenet_tuning(hp):
    model = Sequential()

    model.add(Conv2D(hp.Int('conv1_filters', min_value=4, max_value=32, step=4),
                            kernel_size=(5, 5),
                            strides=(1, 1),
                            activation='tanh',
                            input_shape=input_shape))
    model.add(AveragePooling2D(pool_size=(2, 2), strides=(2, 2)))

    model.add(Conv2D(hp.Int('conv2_filters', min_value=8, max_value=64, step=8),
                            kernel_size=(5, 5),
                            strides=(1, 1),
                            activation='tanh'))
    model.add(AveragePooling2D(pool_size=(2, 2), strides=(2, 2)))

    model.add(Conv2D(128, kernel_size=(5, 5), strides=(1, 1),activation='tanh'))

    model.add(Flatten())

    model.add(Dense(128, activation='tanh'))
    model.add(Dropout(dropout_rate))
    model.add(Dense(num_classes, activation='softmax'))

    model.compile(optimizer=optimizer,
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    return model

# Instantiate the Keras Tuner RandomSearch tuner
tuner = kt.GridSearch(
    build_lenet_tuning,
    objective='val_accuracy',
    directory='lenet_tuner',
    project_name='lenet_tuning'
)

# Perform the hyperparameter search
tuner.search(train_images, train_labels, validation_data=(test_images, test_labels), epochs=epochs)

# Get the best hyperparameters
best_hps = tuner.get_best_hyperparameters(num_trials=1)[0]
# Print the best hyperparameters
print("Best Hyperparameters:")
print(f"conv1_filters: {best_hps.get('conv1_filters')}")
print(f"conv2_filters: {best_hps.get('conv2_filters')}")