#this function is used for tuning (using hyperparameter (hp))
import kerastuner as kt
from keras import layers, models
from keras.optimizers.legacy import SGD
import kerastuner as kt
import matplotlib.pyplot as plt
from task1_1 import load_images,load_labels
#main parameters
input_shape = (32, 32, 1)  #based on my dataset shape
num_classes = 29  #num of labels in the arabic character
learning_rate = 0.00125892541179416752 #result from tuner
batch_size = 32
epochs = 10
dropout_rate=0.2 #result from tuner
momentum=0.9 #common choice

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)

def build_cnn_for_tuning(hp):
    # Build the CNN model
    model = models.Sequential()

    # Convolutional layers
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.MaxPooling2D((2, 2)))

    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))

    # Flatten layer before fully connected layers
    model.add(layers.Flatten())

    # Fully connected layers
    model.add(layers.Dense(128, activation='relu'))

    # Dropout layer with tunable rate
    model.add(layers.Dropout(hp.Float('dropout_rate', min_value=0.2, max_value=0.5, step=0.1)))

    model.add(layers.Dense(num_classes, activation='softmax'))

    # Compile the model with a tunable learning rate
    model.compile(optimizer=SGD(hp.Float('learning_rate', min_value=1e-4, max_value=1e-2, sampling='log'),momentum=momentum),
                loss='categorical_crossentropy',
                metrics=['accuracy'])

    return model

train_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainImages 13440x1024.csv"
train_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainLabel 13440x1.csv"
test_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestImages 3360x1024.csv"
test_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestLabel 3360x1.csv"
train_images=load_images(train_images_path)
train_labels=load_labels(train_labels_path)
test_images=load_images(test_images_path)
test_labels=load_labels(test_labels_path)
print("Train Images Shape:", train_images.shape)
print("Train Labels Shape:", train_labels.shape)

#tuning learning rate and dropout rate
# Instantiate the tuner

tuner = kt.GridSearch(build_cnn_for_tuning, objective='val_accuracy', max_trials=10)

# Perform the random search
tuner.search(train_images, train_labels, epochs=10, validation_data=(test_images, test_labels))

# Get the best hyperparameters
best_hps = tuner.get_best_hyperparameters(num_trials=1)[0]

# Print the best hyperparameters
print("Best Hyperparameters:")
print(f"Learning Rate: {best_hps.get('learning_rate')}")
print(f"Dropout Rate: {best_hps.get('dropout_rate')}")
