import tensorflow as tf
from keras import layers, models
from keras.optimizers.legacy import SGD
import keras_tuner as kt
import numpy as np
import pandas as pd
from keras.utils import to_categorical
import matplotlib.pyplot as plt
from task1_1 import load_images,load_labels
from keras.preprocessing.image import ImageDataGenerator

#main parameters
input_shape = (32, 32, 1)  #based on my dataset shape
num_classes = 29  #num of labels in the arabic character
learning_rate = 0.00125892541179416752 #result from tuner
batch_size = 32
epochs = 10
dropout_rate=0.2 #result from tuner
momentum=0.9 #common choice

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)
#Task 2
#IMPORTANT NOTE: if it gave error on running, delete "untitled_project"  in content dir


# Data augmentation parameters
def build_cnn_with_data_augmentation(hp):
    model = models.Sequential()

    # Convolutional layers
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.MaxPooling2D((2, 2)))

    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))

    # Flatten layer before fully connected layers
    model.add(layers.Flatten())

    # Fully connected layers
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dropout(dropout_rate))  # Dropout layer to prevent overfitting
    model.add(layers.Dense(num_classes, activation='softmax'))

    # Compile the model
    model.compile(optimizer=optimizer,
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    # Data augmentation parameters
    data_gen = ImageDataGenerator(
        width_shift_range=hp.Float('width_shift_range', min_value=0, max_value=0.2, step=0.05),
        height_shift_range=hp.Float('height_shift_range', min_value=0, max_value=0.2, step=0.05),
        shear_range=hp.Float('shear_range', min_value=0, max_value=0.2, step=0.05),
        fill_mode=hp.Choice('fill_mode', values=['constant', 'nearest', 'reflect', 'wrap'])
    )

    # Use the data generator for training
    train_generator = data_gen.flow(train_images, train_labels, batch_size=batch_size)

    # Train the model
    model.fit(train_generator, epochs=epochs, validation_data=(test_images, test_labels))

    return model

train_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainImages 13440x1024.csv"
train_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainLabel 13440x1.csv"
test_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestImages 3360x1024.csv"
test_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestLabel 3360x1.csv"
train_images=load_images(train_images_path)
train_labels=load_labels(train_labels_path)
test_images=load_images(test_images_path)
test_labels=load_labels(test_labels_path)

# Define the tuner
tuner = kt.GridSearch(build_cnn_with_data_augmentation, objective='val_accuracy', max_trials=10)

# Search for the best hyperparameters
tuner.search(train_images, train_labels, epochs=epochs, validation_data=(test_images, test_labels))

# Get the best hyperparameters
best_hps = tuner.get_best_hyperparameters(num_trials=1)[0]

# Print the best hyperparameters
print("Best Hyperparameters:")
print(f"Width Shift Range: {best_hps.get('width_shift_range')}")
print(f"Height Shift Range: {best_hps.get('height_shift_range')}")
print(f"Shear Range: {best_hps.get('shear_range')}")
print(f"Fill Mode: {best_hps.get('fill_mode')}")
