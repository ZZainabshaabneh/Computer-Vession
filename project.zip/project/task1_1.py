import tensorflow as tf
from keras import layers, models
from keras.optimizers.legacy import SGD
import kerastuner as kt
import pandas as pd
from keras.utils import to_categorical
import matplotlib.pyplot as plt

input_shape = (32, 32, 1)  #based on my dataset shape
num_classes = 29  #num of labels in the arabic character
learning_rate = 0.00125892541179416752 #result from tuner
batch_size = 32
epochs = 10
dropout_rate=0.2 #result from tuner
momentum=0.9

optimizer = SGD(learning_rate=learning_rate,momentum=momentum)


def load_images(images_path):
    # Read CSV files into Pandas DataFrames
    images_df = pd.read_csv(images_path, header=None)
    images = images_df.to_numpy().reshape(-1, 32, 32, 1)  # Reshape to (32, 32, 1)
    return images

def load_labels(labels_path):
    # Read CSV files into Pandas DataFrames
    labels_df = pd.read_csv(labels_path, header=None)
    labels = to_categorical(labels_df.to_numpy().flatten())  # One-hot encode labels
    return labels



#main model after tuning parameters
def build_cnn():
    # Build the CNN model
    model = models.Sequential()

    # Convolutional layers
    model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.MaxPooling2D((2, 2)))

    model.add(layers.Conv2D(64, (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((2, 2)))

    # Flatten layer before fully connected layers
    model.add(layers.Flatten())

    # Fully connected layers
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dropout(dropout_rate))  # Dropout layer to prevent overfitting
    model.add(layers.Dense(num_classes, activation='softmax'))

    # Compile the model
    model.compile(optimizer=optimizer,
                loss='categorical_crossentropy',
                metrics=['accuracy'])
    return model



def plot_graphs(history):
    # Create a single figure for all plots
    plt.figure(figsize=(8, 4))

    # Plot Training Loss vs. Epoch
    plt.subplot(2, 2, 1)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss vs. Epoch')
    plt.legend()

    # Plot Training Accuracy vs. Epoch
    plt.subplot(2, 2, 2)
    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title('Training and Validation Accuracy vs. Epoch')
    plt.legend()

    # Adjust layout and display the plot
    plt.tight_layout()
    plt.show()

train_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainImages 13440x1024.csv"
train_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTrainLabel 13440x1.csv"
test_images_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestImages 3360x1024.csv"
test_labels_path = "C:/Users/Administrator/OneDrive/Documents/vision project/Project data set/csvTestLabel 3360x1.csv"
train_images=load_images(train_images_path)
train_labels=load_labels(train_labels_path)
test_images=load_images(test_images_path)
test_labels=load_labels(test_labels_path)



# Train the model
model = build_cnn()
history = model.fit(train_images, train_labels, epochs=epochs,batch_size=batch_size, validation_data=(test_images, test_labels))
plot_graphs(history)